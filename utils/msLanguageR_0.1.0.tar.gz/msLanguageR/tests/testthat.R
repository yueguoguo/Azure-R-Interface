library(testthat)
library(cognitiveR)

test_check("cognitiveR")
