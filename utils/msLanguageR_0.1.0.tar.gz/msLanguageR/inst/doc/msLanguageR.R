## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  
#  # Install devtools
#  if(!require("devtools")) install.packages("devtools")
#  devtools::install_github("yueguoguo/Azure-R-Interface/utils/msLanguageR")
#  library(msLanguageR)

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  text <- "<U+5927><U+6570><U+636E>"
#  
#  translated_text1 <- cognitiveTranslation(text, lanFrom="zh-CHS", lanTo="en", apiKey="a valid key")
#  translated_text1
#  # [1] "Big data"
#  
#  text <- "Big Data"
#  translated_text2 <- cognitiveTranslation(text, lanFrom="en", lanTo="zh-CHS", apiKey="a valid key")
#  translated_text2
#  # [1] "<U+5927><U+6570><U+636E>"
#  
#  translated_text3 <- cognitiveTranslation(text, lanFrom="en", lanTo="zh-CHT", apiKey="a valid key")
#  translated_text3
#  # [1] "<U+5927><U+8CC7><U+6599>"

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  senti_score <- cognitiveSentiAnalysis("I love you", apiKey="a valid key string")
#  senti_score
#  # $documents
#  #       score id
#  # 1 0.9140102  1
#  #
#  # $errors
#  # list()
#  
#  text <- c("I love you", "I hate you", "This is love")
#  senti_scores <- cognitiveSentiAnalysis(text, apiKey="a valid key string")
#  senti_scores
#  # $documents
#  #        score id
#  # 1 0.91401020  1
#  # 2 0.05904578  2
#  # 3 0.91798760  3
#  #
#  # $errors
#  # list()

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  lang1 <- cognitiveLangDetect("English", apiKey="a valid key string")
#  lang1
#  # $documents
#  #   id detectedLanguages
#  # 1  1    English, en, 1
#  #
#  # $errors
#  # list()
#  
#  langs2 <- cognitiveLangDetect(c("English", "<U+5927><U+6570><U+636E>"), langNum=2, apiKey="a valid key string")
#  langs2
#  # $documents
#  #   id             detectedLanguages
#  # 1  1                English, en, 1
#  # 2  2 Chinese_Simplified, zh_chs, 1
#  #
#  # $errors
#  # list()

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  data(text_bbc)
#  
#  topics_detected <- cognitiveTopicDetect(text_bbc, apiKey="a valid key")
#  topics_detected

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  key_phrases <- cognitiveKeyPhrases("Artificial Intelligence is regarded as one of the disruptive technologies in the 21st century", apiKey="a valid key string")
#  key_phrases
#  # $documents
#  #                                                  keyPhrases id
#  # 1 disruptive technologies, century, Artificial Intelligence  1
#  #
#  # $errors
#  # list()

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  text <- c("today is holliday", "hapyp new yaer")
#  
#  text_detected <- cognitiveSpellingCheck(text, apiKey="a valid key")
#  text_detected
#  # $`_type`
#  # [1] "SpellCheck"
#  #
#  # $flaggedTokens
#  #   offset    token         type                suggestions
#  # 1      9 holliday UnknownToken holiday, 0.884147790762446
#  # 2     18    hapyp UnknownToken   happy, 0.884147790762446
#  # 3     28     yaer UnknownToken    year, 0.884147790762446

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  text <- "What did you say?!? I didn't hear about the director's new proposal. It's important to Mr. and Mrs. Smith"
#  
#  tokens <- cognitiveLinguiAnalysis(text, apiKey="a valid key")
#  tokens
#  #                             analyzerId
#  # 1 22a6b758-420f-4745-8a3c-46835a67c0d2
#  # 2 4fa79af1-f22c-408d-98bb-b7d7aeef7f04
#  # 3 08ea174b-bfdb-4e64-987e-602f85da7f72
#  #                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            result
#  # 1                                                                                                           (TOP (SBARQ (WHNP (WP What)) (SQ (VBD did) (NP (PRP you)) (VP (VB say)) (. ?)) (. !) (. ?))), (TOP (S (NP (PRP I)) (VP (VBD did) (RB n't) (VP (VB hear) (PP (IN about) (NP (NP (DT the) (NN director) (POS 's)) (JJ new) (NN proposal))))) (. .))), (TOP (S (NP (PRP It)) (VP (VBZ 's) (ADJP (JJ important) (PP (TO to) (NP (NP (NNP Mr.)) (CC and) (NP (NNP Mrs.) (NNP Smith))))))))
#  # 2                                                                                                                                                                                                                                                                                                                                                                                   WP, VBD, PRP, VBP, ., ., ., PRP, VBD, RB, VB, IN, DT, NN, POS, JJ, NN, ., PRP, VBZ, JJ, TO, NNP, CC, NNP, NNP
#  # 3 19, 48, 36, 0, 20, 69, 4, 3, 3, 3, 1, 1, 1, What, did, you, say, ?, !, ?, 0, 5, 9, 13, 16, 17, 18, What, did, you, say, ?, !, ?, 1, 3, 3, 4, 5, 3, 8, 2, 3, 8, 1, I, did, n't, hear, about, the, director, 's, new, proposal, ., 20, 22, 25, 29, 34, 40, 44, 52, 55, 59, 67, I, did, n't, hear, about, the, director, 's, new, proposal, ., 2, 2, 9, 2, 3, 3, 4, 5, It, 's, important, to, Mr., and, Mrs., Smith, 69, 71, 74, 84, 87, 91, 95, 100, It, 's, important, to, Mr., and, Mrs., Smith

